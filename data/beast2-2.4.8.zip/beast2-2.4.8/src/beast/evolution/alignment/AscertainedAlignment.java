package beast.evolution.alignment;

import beast.core.Description;


@Description("Alignemnt that allows ascertainment correction")
/**
 * This class has merged with Alignment
 * @deprecated use Alignment() instead setting isAscertainedInput to true.
 */
@Deprecated
public class AscertainedAlignment extends Alignment {

} // class AscertainedAlignment
