package beast.core.util;

/**
 * @author Andrew Rambaut
 * @version $Id$
 */
public interface Evaluator {
    double evaluate();
}
