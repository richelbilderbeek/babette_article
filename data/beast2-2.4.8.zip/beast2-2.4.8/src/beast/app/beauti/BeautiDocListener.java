package beast.app.beauti;

/**
 * @author Andrew Rambaut
 * @version $Id$
 */
public interface BeautiDocListener {
    void docHasChanged() throws Exception;
}
