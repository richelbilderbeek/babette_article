library(testthat)
library(beautier)

test_check("beautier")
