context("create_misc_options")

test_that("use", {

  testthat::expect_silent(create_misc_options())
})
