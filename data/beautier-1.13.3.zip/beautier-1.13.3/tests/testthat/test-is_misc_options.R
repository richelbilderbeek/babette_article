context("is_misc_options")

test_that("use", {

  testthat::expect_true(is_misc_options(create_misc_options()))

})
