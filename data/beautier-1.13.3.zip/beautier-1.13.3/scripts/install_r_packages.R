devtools::install_github("richelbilderbeek/beautier", ref = "develop")
devtools::install_github("richelbilderbeek/beastier", ref = "develop")
devtools::install_github("richelbilderbeek/tracerer", ref = "develop")
devtools::install_github("richelbilderbeek/babette", ref = "develop")
