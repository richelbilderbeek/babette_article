context("onLoad")

test_that("use", {

  babette:::.onLoad()

})
